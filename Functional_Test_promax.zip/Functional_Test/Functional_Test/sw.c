#include "iodefine.h"
#include "sw.h"
#include "led.h"


static char count;


int init_sw()
{
	IO.PMR1.BIT.IRQ2 = 1;    // ??????
//	IO.PMR1.BIT.IRQ1 = 1;    // ??????
//	IO.PMR1.BIT.IRQ0 = 1;    // ??????
	IO.PMR1.BIT.IRQ3 = 1;    // ??????
	
	IEGR1.BIT.IEG2 = 0;      // ??????
	
	IRR1.BIT.IRRI2 = 0;      // ??????
	
	IENR1.BIT.IEN2 = 1;      // ?????????
	
	
	
	
	IEGR1.BIT.IEG3 = 0;      // ??????
	
	IRR1.BIT.IRRI3 = 0;      // ??????
	
	IENR1.BIT.IEN3 = 1;      // ?????????




//	IEGR1.BIT.IEG0 = 0;      // ??????
	
//	IRR1.BIT.IRRI0 = 0;      // ??????
	
//	IENR1.BIT.IEN0 = 1;      // ?????????



}

#pragma section IntPRG
__interrupt(vect=16) void INT_IRQ2(void)
{


	IRR1.BIT.IRRI2 = 0;
	
	offLED2();
	onLED1();
	
/*	
	if(onLED1()){
		offLED1();
	}else{
		onLED1();
	}
	if(onLED2()){
		offLED2();
	}else{
		onLED2();
	}
*/
}


__interrupt(vect=17) void INT_IRQ3(void) {
	IRR1.BIT.IRRI3 = 0;      // �t���O�N���A
	onLED2();
	offLED1();
	
/*	
	if(onLED1()){
		offLED1();
	}else{
		onLED1();
	}
	if(onLED2()){
		offLED2();
	}else{
		onLED2();
	}
*/

	/* sleep(); */}
