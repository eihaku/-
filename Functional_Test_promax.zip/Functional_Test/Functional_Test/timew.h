#ifndef _TIMEW_H_
#define _TIMEW_H_

void PWM_init();
void PWM_setGRD(unsigned int grd);
void PWM_setGRA(unsigned int gra);

#endif

