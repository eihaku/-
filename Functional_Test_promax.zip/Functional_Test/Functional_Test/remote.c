#include "iodefine.h"

#include "remote.h"

unsigned char gCount;
unsigned char gCha;
unsigned char gwaFlag;

	NecFrameCode gRemoCode;		

	unsigned char status = 0;
	char countData;

	unsigned char DataA = 0;
	unsigned char DataB = 0;
	unsigned int remData;
	char bitFlag = 0;
	char bitCount = 0;
	unsigned short custCode;
	unsigned short keyCode;




int init_remote()
{
	init_TimeA();
	init_Irq1();
}


int init_Irq1()
{
	IO.PMR1.BIT.IRQ1 = 1;    // ���肱�ݑI��
	
	IEGR1.BIT.IEG1 = 0;      // ������G�b�W
	
	IRR1.BIT.IRRI1 = 0;      // �t���O�N���A
	
	IENR1.BIT.IEN1 = 1;      // ���荞�݃C�l�[�u��
}





#pragma section IntPRG
__interrupt(vect=15) void INT_IRQ1(void)
{
	IRR1.BIT.IRRI1 = 0;      // �t���O�N���A

	gCount = getCount(); 
//	nextCount = gCount;
	
	// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	switch(status){
	case fStatus: //���߂�
		
		DataA = gCount;
		status = 1;
		break;

	case nStatus: //�n�߂Ă���
		DataB = DataA;
		DataA = gCount;
		gCha = DataA - DataB;
		
		if(gCha < MAX_24T && gCha > MIN_24T){
			status = 2;
		}else{
			status = 0;
			gCha = 0;
		}
		break;
	case nnStatus: //DATA�@status
		DataB = DataA;
		DataA = gCount;
		gCha = DataA - DataB;
		
		// ��r�b�g�̒l���擾
		bitFlag = chBit(gCha);
		
		if(bitFlag > 1){
			status = 0;
			bitCount = 0;
			gRemoCode.FrameCode = 0;
			gCha = 0;
			break;
		}
					
		gRemoCode.FrameCode <<= 1;
		gRemoCode.FrameCode += bitFlag;


		bitCount ++;
		if(bitCount == 32){
			bitCount = 0;
			status = 3;
			printKeyData(gRemoCode.D.ksmCode, gRemoCode.D.dataFCode);
			status = 0;

		}
		gCha = 0;
		break;
		
	case nnnStatus:
		//if((remData >>16) == 0xBF40)
	//	custCode = 0xAABB;
	//	custCode = gRemoCode.D.ksmcode;
	//	keyCode = gRemoCode.d.dataFCode + gRemoCode.d.dataNCode;
	//printKeyData(gRemoCode.D.ksmCode, gRemoCode.D.dataFCode);
	gwaFlag = 1;

	default:
		break;
	}
	// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

}


unsigned char chBit(unsigned char data)
{
	unsigned char res = 2;
	if(data < MIN_24T && data != 0)
	{	
		if(data < MAX_2T && data > MIN_2T){
			res = 0;
		}else if(data < MAX_4T && data > MIN_4T){
			res = 1;
		}
	}
	return res;
}

