
#ifndef _REMOTE_H_
#define _REMOTE_H_


#define MAX_24T 143
#define MIN_24T 121
#define MAX_4T 26
#define MIN_4T 18
#define MAX_2T 13
#define MIN_2T 9

// void A24T();
// void A4T();
// void A2T();

enum chStatus
{
	fStatus,  //0
	nStatus,  //1
	nnStatus, //2
	nnnStatus //3
};


typedef union _NecFrameCode{
	unsigned int FrameCode;
	struct resData{
		unsigned short dataFCode;
		//unsigned char dataNCode;
		unsigned short ksmCode;
	} D;
}NecFrameCode;

extern NecFrameCode gRemoCode;		
extern unsigned char gwaFlag;

int init_Irq1();
int init_TimeA();
int init_remote();
unsigned char getCount();
unsigned char chBit(unsigned char data);

#endif  // _REMOTE_H_

