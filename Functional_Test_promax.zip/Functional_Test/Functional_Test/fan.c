#include "fan.h"
#include "iodefine.h"
//#include "ad.h"
#include "machine.h"
#include "temperature.h"
#include "AD.h"
#include "timew.h"

const unsigned int g_fanPeriod=0xffff;
unsigned int g_fanLevel=0x0000;

void initFan(void)
{
	TW.TIERW.BIT.IMIEA=0;

	TW.TMRW.BIT.BUFEB=0;
	TW.TMRW.BIT.PWMD=1;
	TW.TCRW.BIT.CCLR=1;
	TW.TCRW.BIT.CKS=0;//neibushizhong
	TW.TIOR1.BIT.IOD=1;//sheding  p84
	TW.TSRW.BIT.IMFA=0;
			
	TW.GRA = g_fanPeriod;
	TW.GRD = g_fanLevel;
	
	//TW.TIERW.BIT.OVIE=1;
	TW.TIERW.BIT.IMIEA=1;
	TW.TMRW.BIT.CTS=1;
}

void setFanLevel(unsigned int level)
{
	unsigned int gra;
	
	
	switch(level){//���x���𔻒f����
		case 1:
			g_adRV2 = 60000;	//���x���P
			break;
		case 2:
			g_adRV2 = 40000;	//���x���Q
			break;
		case 3:
			g_adRV2 = 0;		//���x���R
			break;
	}
#if 0
/*
	if(temper >= 30){
		g_adRV2 = 60000;
	}
	else if(temper <= 20){
		g_adRV2 = 0;
	}else if(temper <= 29 && temper >= 25){
		g_adRV2 = 40000;
	}else if(temper <= 24 && temper >= 21){
		g_adRV2 = 20000;
	}
*/
#endif
	gra = g_adRV2;

	PWM_setGRD(gra);
}

unsigned int getFanLevel(void)
{
	return g_fanLevel;
}

	
