#ifndef _WLCD_H_
#define _WLCD_H_

/* Lcd アクセス時に時間待ちをします */
void waitWLCD(unsigned int mSec);
/* Lcd からデータ読み込み */
unsigned char readWLCD(unsigned char rs);
/* Lcd へデータ書き込み */
void writeWLCD(unsigned char data, unsigned char rs);
/* Lcd の初期化をします */
void initWLCD(void);
/* 画面のクリアをします */
void clearWLCD(void);
/* LCD 表示をオンします */
void onWLCD(void);
/* LCD 表示をオフします */
void offWLCD(void);
/* LCD のカーソルを表示します */
void curOnWLCD(void);
/* LCD のカーソルを表示しません */
void curOffWLCD(void);
/* カーソル位置を移動します */
void xyWLCD(unsigned char x, unsigned char y);
/* 文字列を表示します */
void putsWLCD(char *str);
/* データを表示します */
void putWLCDNumber(signed char keta, unsigned int number);

#endif /* _WLCD_H_ */