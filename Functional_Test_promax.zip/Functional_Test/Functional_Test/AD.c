#include "iodefine.h"

#include "AD.h"

#define LCD_WAIT_LOOP_FOR_1mSec 3500

unsigned int g_adRV2;
unsigned int g_adRV3;
unsigned int ad_data2;

void waitTimeMS(unsigned int mSec)
{
	unsigned int loop1, loop2;
	for (loop1 = 0; loop1 < mSec; loop1++) {
		for (loop2 = 0; loop2 < LCD_WAIT_LOOP_FOR_1mSec; loop2++);
	}
}

void initAD(void)
{
	TV.TCRV1.BIT.TRGE=0;
	AD.ADCSR.BIT.SCAN=1;
	AD.ADCSR.BIT.CKS=1;
	AD.ADCSR.BIT.CH=0x001;
	AD.ADCSR.BIT.ADIE=0;
}

		
int getAD(void)
{
//	int ad_data;					/* A-D???????????????? */
	
	AD.ADCSR.BIT.ADST = 1;			/* A-D???? */
	
	while (!AD.ADCSR.BIT.ADF);		/* ?????? */
	
	ad_data2 = AD.ADDRC >> 6;		/* A-D???????(ad-data)??? */		
	AD.ADCSR.BIT.ADF = 0;			/* ??????????? */
	

	return (ad_data2);				/* A-D?????????? */
}
	

	

