#ifndef _TEMPERATURE_H_
#define _TEMPERATURE_H_

extern unsigned char g_ad5;
extern unsigned short g_ad51111;



int getSensor(void);
void init_temperature();
int get_temperature();
void ADST();



#endif   //_TEMPERATURE_H_
