-------- PROJECT GENERATOR --------
PROJECT NAME :	Functional_Test
PROJECT DIRECTORY :	C:\WorkSpace\Functional_Test\Functional_Test
CPU SERIES :	300H
CPU TYPE :	36094F
TOOLCHAIN NAME :	Renesas H8S,H8/300 Standard Toolchain
TOOLCHAIN VERSION :	7.0.0.0
GENERATION FILES :
    C:\WorkSpace\Functional_Test\Functional_Test\dbsct.c
        Setting of B,R Section
    C:\WorkSpace\Functional_Test\Functional_Test\typedefine.h
        Aliases of Integer Type
    C:\WorkSpace\Functional_Test\Functional_Test\sbrk.c
        Program of sbrk
    C:\WorkSpace\Functional_Test\Functional_Test\iodefine.h
        Definition of I/O Register
    C:\WorkSpace\Functional_Test\Functional_Test\intprg.c
        Interrupt Program
    C:\WorkSpace\Functional_Test\Functional_Test\resetprg.c
        Reset Program
    C:\WorkSpace\Functional_Test\Functional_Test\Functional_Test.c
        Main Program
    C:\WorkSpace\Functional_Test\Functional_Test\sbrk.h
        Header file of sbrk file
    C:\WorkSpace\Functional_Test\Functional_Test\stacksct.h
        Setting of Stack area
START ADDRESS OF SECTION :
 H'000000400	PResetPRG,PIntPRG
 H'000000800	P,C,C$DSEC,C$BSEC,D
 H'00000FB80	B,R
 H'00000FE80	S

* When the user program is executed,
* the interrupt mask has been masked.
* 
* *** H8/36094F ***

DATE & TIME : 2023/9/29 14:14:06
