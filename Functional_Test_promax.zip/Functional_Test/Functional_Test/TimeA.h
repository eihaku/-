
#ifndef _TIMEA_H_
#define _TIMEA_H_


int init_TimeA();

unsigned char getCount();






#endif  //  _TIMEA_H_