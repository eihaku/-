
#ifndef _AD_H_
#define _AD_H_

void initAD();
int getAD();

extern unsigned int g_adRV2;
extern unsigned int g_adRV3;

#endif   //_AD_H_