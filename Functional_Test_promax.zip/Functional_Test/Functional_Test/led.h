#ifndef _LED_H_
#define _LED_H_

/* LED?????? */
void initLED(void);
/* LED1????? */
void onLED1(void);
/* LED1??? */
void offLED1(void);
/* LED2????? */
void onLED2(void);
/* LED2??? */
void offLED2(void);

#endif