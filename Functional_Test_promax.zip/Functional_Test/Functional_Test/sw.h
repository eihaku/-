#ifndef _SW_H_
#define _SW_H_





int init_sw();



#endif  // _SW_H_

