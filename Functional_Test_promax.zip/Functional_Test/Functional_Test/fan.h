#ifndef _Fan_H_
#define _Fan_H_


enum chReStatus
{
	cleanS,      //0
	fDataS,      //1
	nDataS,      //2
	decisionS    //3
};

void initFan(void);

void setFanLevel(unsigned int level);
unsigned int getFanLevel(void);


#endif