#include "iodefine.h"

#include "TimeA.h"

int init_TimeA()
{
	TA.TMA.BIT.CKSI=2;   // ��/2048 �J�E���^0.1ms
	
}

unsigned char getCount()
{
	return TA.TCA;
}



